from project.animal import Animal

a = Animal()
print(a.eat)
print(a.bark)
print(a.meow)
