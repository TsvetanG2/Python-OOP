from project.fruit import Fruit

f = Fruit("orange", "2024-01-06")
print(f.name)
